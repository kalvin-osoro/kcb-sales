package com.ekenya.rnd.backend.fskcb.QSSAdapter.datasource.entities;

public enum QssAlertStatus {
    PENDING,DELIVERED,READ
}
